//
//  ViewController.swift
//  XMLParsingDemo1
//
//  Created by Mac on 20/09/18.
//  Copyright © 2018 Mac. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource,XMLParserDelegate {

    @IBOutlet weak var tbl: UITableView!
    var arr:[Any] = []
    var brr:[String] = []
    var content = ""
    var title1 = ""
    var bol = true
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let url = URL(string: "https://timesofindia.indiatimes.com/rssfeeds/4719148.cms")
        
        let request = URLRequest(url: url!)
        
        let session = URLSession.shared
        let datatask = session.dataTask(with: request) { (data, resp, err) in
        
            let parse = XMLParser(data: data!)
            parse.delegate = self
            parse.parse()
        }
        datatask.resume()
        
    }
    func parserDidStartDocument(_ parser: XMLParser) {
        arr = []
    }
    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String] = [:]) {
         if elementName == "item"
         {
            brr = []
        }
    }
    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?) {
        if elementName == "title"
        {
            brr.append(content)
        }
        else if elementName == "item"
        {
            arr.append(brr)
        }
        
    }
    func parser(_ parser: XMLParser, foundCharacters string: String) {
        if bol == true
        {
           title1 = string
            
            bol = false
        }
         content = string
    }
    func parserDidEndDocument(_ parser: XMLParser) {
        DispatchQueue.main.async {

            self.tbl.reloadData()
        
        }
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arr.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        
        let title = arr[indexPath.row] as! [String]
        
        cell.textLabel?.text = title[0]
        return cell
    }
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return title1
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }


}

